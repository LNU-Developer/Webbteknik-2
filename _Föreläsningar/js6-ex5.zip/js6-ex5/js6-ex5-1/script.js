// JavaScript Document

// Globala variabler
var resElem;	// Referens till elementet för resultat

// Initiera globala variabler och koppla funktion till knapp
function init() {
	resElem = document.getElementById("result");
	getData(); // Hämta parametrar
} // End init
addListener(window,"load",init);

// Funktion för att avläsa parametrarna i url:en
// I detta exempel skrivs de endast ut på webbsidan
function getData() {
	var parStr;		// Parametersträngen i url:en
	var parArr;		// Array som används för uppdelning av strängen i separata parametrar
	var par;		// Array som temporärt används för uppdelning av namn och värde för en parameter
	var i;			// Loopvariabel
	
	parStr = location.search; // T.ex. en sträng på formen ?text1=En+text&choice2=gul
	resElem.innerHTML = "<p>" + parStr + "</p>";
	
	parStr = parStr.substring(1); // Ta bort frågetecknet
	resElem.innerHTML += "<p>" + parStr + "</p>";
	
	parArr = parStr.split("&"); // Dela upp parametrarna i en array
	
	for (i=0; i<parArr.length; i++) {
		par = parArr[i].split("="); // Dela upp i namn och värde
		resElem.innerHTML += "<p>Parameternamn: " + par[0] + "<br>Parametervärde: " + par[1] + "</p>";
	}
} // End getData
