// JavaScript Document

// Globala variabler

// Initiera globala variabler och koppla funktion till knapp
function init() {
	addListener(document.getElementById("sendBtn"),"click",sendData);
} // End init
addListener(window,"load",init);

// Funktion för att skicka data i url:en
function sendData() {
	var par1, par2; // Två parametrar som ska skickas
	par1 = "en grön";
	par2 = "fågel";
	location.href = "receiver.htm?" + escape(par1) + "&" + escape(par2);
} // End sendData