// JavaScript Document

// Globala variabler
var resElem;	// Referens till elementet för resultat

// Initiera globala variabler och koppla funktion till knapp
function init() {
	resElem = document.getElementById("result");
	getData(); // Hämta parametrar
} // End init
addListener(window,"load",init);

// Funktion för att avläsa parametrarna i url:en
function getData() {
	var parStr; // Parametersträngen i url:en
	var parArr; // Array som används för uppdelning av strängen i separata parametrar
	var i; // Loopvariabel
	
	parStr = location.search.substring(1); // Avläs parametersträngen
	parArr = parStr.split("&"); // Dela upp parametrarna i en array
	
	for (i=0; i<parArr.length; i++) {
		resElem.innerHTML += "<p>Parameter: " + unescape(parArr[i]) + "</p>";
	}
} // End getData
