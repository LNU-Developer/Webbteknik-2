// JavaScript Document

// Globala variabler
var carImgElem;	// Referens till bild med bil
var msgElem;	// Referens till elementet för meddelanden
var carImgs;	// Array med filnamn för bilderna med bilen
var carDir;		// Riktning för bilen

// Initiera globala variabler och koppla funktion till knapp
function init() {
	carImgElem = document.getElementById("car");
	msgElem = document.getElementById("message");
	addListener(document,"keydown",checkKey);
	carImgs = ["car_up.png","car_right.png","car_down.png","car_left.png"];
	carDir = 0;
} // End init
addListener(window,"load",init);

function checkKey(e) {
	var k = e.keyCode;
	switch (k) {
		case 37: // Pil vänster
		case 90: // Z
			msgElem.innerHTML = "Sväng vänster";
			carDir--;
			if (carDir < 0) carDir = 3;
			carImgElem.src = "pics/" + carImgs[carDir];
			break;
		case 39:  // Pil höger
		case 173: // -
			msgElem.innerHTML = "Sväng höger";
			carDir++;
			if (carDir > 3) carDir = 0;
			carImgElem.src = "pics/" + carImgs[carDir];
			break;
		case 32: // mellanslag
			msgElem.innerHTML = "Kör framåt";
			break;
	}
} // End checkKey