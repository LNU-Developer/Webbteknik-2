// JavaScript Document

// Globala variabler
var msgElem;	// Referens till elementet för meddelanden

// Initiera globala variabler och koppla funktion till knapp
function init() {
	addListener(document.getElementById("box"),"click",boxClick);
	msgElem = document.getElementById("message");
} // End init
addListener(window,"load",init);

// Klick på någon av de inre boxarna
function boxClick(e) {
	msgElem.innerHTML = "this = " + this + "<br>e.target = " + e.target;
} // End boxClick
