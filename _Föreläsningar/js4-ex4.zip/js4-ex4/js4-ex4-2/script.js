// JavaScript Document

// Globala variabler
var msgElem;	// Referens till elementet för meddelanden

// Initiera globala variabler och koppla funktion till knapp
function init() {
	var i;			// Loopvariabel
	var outerBox;	// Yttre div-element för boxarna
	var boxes;		// Array med de inre boxarna
	var formElem;	// form-elementet
	
	outerBox = document.getElementById("boxes");
	addListener(outerBox,"click",outerBoxClick);
	
	boxes = outerBox.getElementsByTagName("div");
	for (i=0; i<boxes.length; i++) {
		addListener(boxes[i],"click",boxClick);
	}
	
	formElem = document.getElementById("testForm");
	addListener(formElem,"submit",checkForm);
	
	msgElem = document.getElementById("message");
} // End init
addListener(window,"load",init);

// Klick på den yttre boxen
function outerBoxClick(e) {
	msgElem.innerHTML = "Du klickade i position " + e.clientX + "," + e.clientY;
} // End outerBoxClick

// Klick på någon av de inre boxarna
function boxClick(e) {
	var symbols = ["&star;","&otimes;","&cupdot;","&plusb;","&bowtie;","&smashp;"]; // Symboler till boxen
	var oldSymb= this.innerHTML; // Gamla symbolen i boxen
	while (oldSymb == this.innerHTML) {
		this.innerHTML = symbols[Math.floor(symbols.length*Math.random())];
	}
	if (e.altKey) this.style.color = "#00F";
	else this.style.color = "#FF0";
	msgElem.innerHTML = "";
	e.stopPropagation();
} // End boxClick

// Kontrollera formuläret
function checkForm(e) {
	// Kontroll av formuläret
	// Om något saknas eller är på fel form utför man e.preventDeafult(), för att formuläret inte ska skickas
	msgElem.innerHTML = "Ej korrkt ifyllt. Formuläret skickas ej.";
	e.preventDefault();
} // End checkForm
