// JavaScript Document

// Globala variabler
var boxElem;	// Referens till boxen
var dropElem;	// Referens till drop-rutan

// Initiera globala variabler och koppla funktion till knapp
function init() {
	var i;		// Loopvariabel
	var boxes;	// Array med boxarna
	boxes = document.getElementById("boxes").getElementsByTagName("div");
	for (i=0; i<boxes.length; i++) {
		boxes[i].draggable = true;
		addListener(boxes[i],"dragstart",dragStarted);
	}
	dropElem = document.getElementById("dropZone");
	addListener(dropElem,"dragover",boxDropped);
	addListener(dropElem,"drop",boxDropped);
} // End init
addListener(window,"load",init);

// En box börjar dras.
function dragStarted(e) {
	e.dataTransfer.setData("text",this.innerHTML);
	boxElem = this;
} // End dragStarted

// Hantera händelserna dragover och drop
// Endast drop används i detta exempel
function boxDropped(e) {
	e.preventDefault();
	if (e.type == "drop") {
		dropElem.innerHTML += "<p>" + e.dataTransfer.getData("text") + "</p>";
		boxElem.style.display = "none";
	}
} // End boxDropped