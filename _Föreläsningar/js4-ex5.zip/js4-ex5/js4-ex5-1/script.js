// JavaScript Document

// Globala variabler

// Initiera globala variabler och koppla funktion till knapp
function init() {
	var i;		// Loopvariabel
	var boxes;	// Array med boxarna
	boxes = document.getElementById("boxes").getElementsByTagName("div");
	for (i=0; i<boxes.length; i++) {
		boxes[i].draggable = true;
		addListener(boxes[i],"dragstart",dragStarted);
	}
} // End init
addListener(window,"load",init);

// En box börjar dras.
function dragStarted(e) {
	e.dataTransfer.setData("text",this.innerHTML);
} // End dragStarted
