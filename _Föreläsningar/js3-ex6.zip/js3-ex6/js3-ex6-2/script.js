// JavaScript

// Globala variabler
var resultElem; // Referens till div-element för resultat
var diceElems; // Array med referenser till img-elementen för tärningarna

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	resultElem = document.getElementById("result");
	document.getElementById("allBtn").onclick = throwAllDice;
	diceElems = document.getElementById("dice").getElementsByTagName("img");
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Generera ett slumptal mellan 1 och 6. Bestäm ny url utifrån talet och uppdatera bilden på tärningen.
function oneDice(imgNr) {
	var diceValue; // Tärningens värde (antal prickar)
	var newImgUrl; // URL för den nya bilden som ska läggas in i img-elementet
	diceValue = Math.floor(6*Math.random())+1; // Slumptal mellan 1 och 6
	newImgUrl = "pics/" + diceValue + ".png"; // Bestäm ny url med hjälp av slumptalet
	diceElems[imgNr].src = newImgUrl; // Uppdatera img-taggen
	return diceValue; // Returnera tärningens värde
} // End oneDice

// Kasta alla tärningar
function throwAllDice() {
	var i; // Loopvariabel
	var sum; // Summan av alla tärningar
	sum = 0;
	for (i=0; i<diceElems.length; i++) {
		sum = sum + oneDice(i);
	}
	resultElem.innerHTML = "<p>Summan av tärningarna är " + sum + "</p>";
} // End throwAllDice
