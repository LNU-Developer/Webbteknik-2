// JavaScript Document

// Globala variabler
var playerDiceElems; // Array med referenser till img-taggarna för spelarens tärningar
var bankDiceElems; // Array med referenser till img-taggarna för bankens tärningar
var playerSumElem; // Referens till element för spelarens summa
var bankSumElem; // Referens till element för bankens summa
var newGameBtn, oneMoreBtn, throwBankBtn; // Referenser till knapparna
var resultElem; // Referens till div-tagg för resultat
var playerSum; // Summan av spelarens tärningar
var nextDiceNr; // Index för nästa tärning som ska kastas

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	playerDiceElems = document.getElementById("playerDice").getElementsByTagName("img");
	bankDiceElems = document.getElementById("bankDice").getElementsByTagName("img");
	playerSumElem = document.getElementById("playerSum");
	bankSumElem = document.getElementById("bankSum");
	resultElem = document.getElementById("result");
	newGameBtn = document.getElementById("newGameBtn");
	oneMoreBtn = document.getElementById("oneMoreBtn");
	throwBankBtn = document.getElementById("throwBankBtn");
	newGameBtn.onclick = newGame;
	oneMoreBtn.onclick = oneMore;
	throwBankBtn.onclick = throwBank;
	activeButtons(1,0,0); // Initiera aktivering av knapparna
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Starta spelet och kasta tre tärningar
function newGame() {
	var i;
	removeAllDice(); // Ta bort alla tärningsbilder
	playerSum = 0;
	for (i=0; i<3; i++) { // Kasta de tre första tärningarna
		playerSum += oneDice("player",i);
	}
	playerSumElem.innerHTML = "<p>Summan av tärningarna är " + playerSum + "</p>";
	nextDiceNr = 3;
	activeButtons(0,1,1);
} // End newGame

// Spelaren kastar en tärning till
function oneMore() {
	playerSum += oneDice("player",nextDiceNr++); // Kasta tärningen
	playerSumElem.innerHTML = "<p>Summan av tärningarna är " + playerSum + "</p>";
	if (nextDiceNr == playerDiceElems.length) { // Sista tärningen är kastad
		activeButtons(0,0,1);
	}
	if (playerSum > 21) {
		resultTag.innerHTML = "<p>Du fick mer än 21. Du förlorade.</p>";
		activeButtons(1,0,0);
	}
} // End oneMore

// Banken kastar sina tärningar
function throwBank() {
	var i; // Loopvariabel
	var bSum; // Summan av bankens tärningar
	bSum = 0;
	for (i=0; i<bankDiceElems.length; i++) {
		bSum += oneDice("bank",i);
		bankSumElem.innerHTML = "<p>Summan av tärningarna är " + bSum + "</p>";
		if (bSum > 21) {
			resultElem.innerHTML = "<p>Banken fick mer än 21. Du vann.</p>";
			break; // Lämna loopen
		}
		else if (bSum >= playerSum) {
			resultElem.innerHTML = "<p>Banken fick mer än dig eller lika mycket. Banken vann.</p>";
			break; // Lämna loopen
		}
	} // End loop
	if (playerSum > bSum) {
		resultElem.innerHTML = "<p>Du fick mer än banken. Du vann.</p>";
	}
	activeButtons(1,0,0);
} // End throwBank

// Kasta en tärning
function oneDice(who,imgNr) {
	var diceValue; // Tärningens värde (antal prickar)
	var newImgUrl; // URL för den nya bilden som ska läggas in i img-elementet
	diceValue = Math.floor(6*Math.random())+1;
	newImgUrl = "pics/" + diceValue + ".png";
	if (who == "player") playerDiceElems[imgNr].src = newImgUrl;
	else bankDiceElems[imgNr].src = newImgUrl;
	return diceValue;
} // End oneDice

// Aktivera eller deaktivera knapparna
function activeButtons(b1,b2,b3) { // Parametrarna är 0 för att inaktivera och 1 för att aktivera
	if (b1 == 0) newGameBtn.disabled = true; // Inaktivera knappen för nytt spel
	else newGameBtn.disabled = false; // Aktivera knappen för nytt spel
	
	if (b2 == 0) oneMoreBtn.disabled = true; // Inaktivera knappen för en tärning till
	else oneMoreBtn.disabled = false; // Aktivera knappen för en tärning till
	
	if (b3 == 0) throwBankBtn.disabled = true; // Inaktivera knappen för bankens kast
	else throwBankBtn.disabled = false; // Aktivera knappen för bankens kast
} // End activeButtons

// Lägg in 0.png i alla img-taggar, så att tärningsbilderna tas bort
function removeAllDice() {
	var i; // Loopvariabel
	for (i=0; i<playerDiceElems.length; i++) {
		playerDiceElems[i].src = "pics/0.png";
	}
	playerSumElem.innerHTML = ""; // Ta också bort summan
	for (i=0; i<bankDiceElems.length; i++) {
		bankDiceElems[i].src = "pics/0.png";
	}
	bankSumElem.innerHTML = "";
} // End removeAllDice