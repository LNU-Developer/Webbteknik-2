// JavaScript

// Globala variabler
var resultElem; // Referens till div-element för resultat

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	resultElem = document.getElementById("result");
	document.getElementById("allBtn").onclick = allP;
	document.getElementById("block1Btn").onclick = block1P;
	document.getElementById("block2Btn").onclick = block2firstP;
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Ta fram referens till alla p-element i dokumentet och skriv ut deras innehåll
function allP() {
	var pArr; // Array med referenser till p-elementen
	var i; // Loopvariabel
	resultElem.innerHTML = "";
	pArr = document.getElementsByTagName("p");
	for (i = 0; i < pArr.length; i++) {
		resultElem.innerHTML += pArr[i].innerHTML +"<br>";
	}
} // End allP

// Ta fram referens till alla p-element i block1 och skriv ut deras innehåll
function block1P() {
	var pArr; // Array med referenser till p-elementen
	var i; // Loopvariabel
	resultElem.innerHTML = "";
	pArr = document.getElementById("block1").getElementsByTagName("p");
	for (i = 0; i < pArr.length; i++) {
		resultElem.innerHTML += pArr[i].innerHTML +"<br>";
	}
} // End block1P

// Ta fram referens till första p-element i block2 och skriv ut dess innehåll
function block2firstP() {
	var pElem; // Referenser till första p-elementet
	pElem = document.getElementById("block2").getElementsByTagName("p")[0];
	resultElem.innerHTML = pElem.innerHTML;
} // End block2firstP