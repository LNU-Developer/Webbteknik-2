// JavaScript Document

// Globala variabler
var cardElems;	// Array med referenser till korten
var cardIx;		// Index till det kort som ligger främst

// Initiera globala variabler och koppla funktion till knapp
function init() {
	var i;	// Loopvariabel
	cardElems = document.getElementById("cards").getElementsByTagName("div");
	for (i=0; i<cardElems.length; i++) {
		cardElems[i].style.left = 60*i+"px";
		cardElems[i].style.top = 20*i + "px";
	}
	cardIx = 0;
	updateCards();
	addListener(document.getElementById("leftBtn"),"click",browseLeft);
	addListener(document.getElementById("rightBtn"),"click",browseRight);
} // End init
addListener(window,"load",init);

// Bläddra åt vänster
function browseLeft() {
	if (cardIx > 0) cardIx--;
	updateCards();
} // End browseLeft

// Bläddra åt höger
function browseRight() {
	if (cardIx < cardElems.length-1) cardIx++;
	updateCards();
} // End browseRight

// Lägg aktuellt kort längst fram och justera ordning för övriga kort
function updateCards() {
	var i;	// Loopvariabel
	var z;	// Nya värden på z-index
	// Kortet som ska ligga längst fram
	z = 100;
	cardElems[cardIx].style.backgroundColor = "#FC6";
	cardElems[cardIx].style.zIndex = z;
	// Alla kort till vänster
	z = 99;
	for (i=cardIx-1; i>=0; i--) {
		cardElems[i].style.backgroundColor = "#FFC";
		cardElems[i].style.zIndex = z--;
	}
	// Alla kort till höger
	z = 99;
	for (i=cardIx+1; i<cardElems.length; i++) {
		cardElems[i].style.backgroundColor = "#FFC";
		cardElems[i].style.zIndex = z--;
	}
} // End updateCards