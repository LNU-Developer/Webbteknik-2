// JavaScript

// Deklaration av variabler
var nr1, nr2, nr3, result;
var str;

str = Java + Script;  // Fel 2: Glömt citattecken

str = str +  är kul";    // Fel 1: Glömt inledande citattecken

nr1 = 3;
nr2 = 4;

result = Nr1 + Nr2;    // Fel 3: Variablerna är deklarerade som nr1 och nr2, men här används Nr1 och Nr2

nr2 = "5";            // Fel som ej upptäcks av debuggern: Talet ska inte omges av citattecken
result = 2*(nr1 + nr2);
//alert(nr1+nr2);
//console.log(nr1+nr2);   // Skriver ut värdet av i debuggerns konsol
alart(result);         // Fel 4: felstavat alert
