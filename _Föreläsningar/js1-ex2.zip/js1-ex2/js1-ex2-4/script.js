// JavaScript
/* ----- Exempel 2-4 ----- */

// Deklaration av variabler
var nr1, result;
var a, colors;

a = [];
colors = ["röd","grön","blå","gul"];

nr1 = prompt("Ange ett tal mellan 0 och 3");
alert("Du får då färgen " + colors[nr1]);

a[0] = 34;
a[1] = 72;
a[2] = 29;
result = a[0] + a[1] + a[2];
alert("Summan är " + result);
