// JavaScript
/* ----- Exempel 2-2 ----- */

// Deklaration av variabler
var nr1, nr2, nr3, result;
var str;

str = "En text";
alert(str);

str = 'Kursen "Webbteknik 2" handlar om JavaScript.';
alert(str);

str = "Rad ett\nRad två";
alert(str);

nr1 = 5;
nr2 = 3.14;
result = nr1 + nr2;
alert(result);

result = 123000000000 * 456000000000;
alert(result);

result = str * nr1;
alert(result);

alert(nr3);

result = nr2 / (nr1 - 5);
alert(result);
