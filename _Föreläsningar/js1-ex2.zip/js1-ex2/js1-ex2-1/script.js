// JavaScript
/* ----- Exempel 2-1 ----- */

// Deklaration av variabler
var nr1, nr2, result;

nr1 = 5;
nr2 = 7;
result = nr1 * nr2;
alert(result);

nr1 = 8;
result = 2 * nr1 + nr2;
alert(result);
