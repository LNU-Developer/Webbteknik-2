// JavaScript

// Deklaration av variabler
var age, month;

age = prompt("Hur gammal är du?");
month = age * 12;
alert("Ojdå, det är " + month + " månader");
