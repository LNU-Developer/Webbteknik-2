// JavaScript Document

// Globala variabler
var formElem;	// Referens till formuläret
var msgElem;	// Referens till elementet för meddelanden
var re;			// Ett reguljärt uttryck

// Initiera globala variabler och koppla funktion till knapp
function init() {
	formElem = document.getElementById("contactForm");
	msgElem = document.getElementById("message");
	addListener(formElem.testBtn1,"click",testRE);
	addListener(formElem.testBtn2,"click",matchRE);
	//re = /\d{3} ?\d{2}/;		// Mönstret finns någonstans i strängen  12345 123 45
	re = /^\d{3} ?\d{2}$/;	// Mönstret finnas mellan början och slut av strängen
} // End init
addListener(window,"load",init);

// Kontrollera det reguljära uttrycket mot innehållet i textfältet
function testRE() {
	var checkText;	// Text i textfältet
	checkText = formElem.zipcode.value;
	msgElem.innerHTML = re.test(checkText);
	if (re.test(checkText)) msgElem.innerHTML += " --- OK";
	else msgElem.innerHTML += " --- Fel";
} // End testRE

// Kontrollera innehållet i textfältet mot det reguljära uttrycket
function matchRE() {
	var checkText;	// Text i textfältet
	checkText = formElem.zipcode.value;
	msgElem.innerHTML = checkText.match(re);
	if (checkText.match(re)) msgElem.innerHTML += " --- OK";
	else msgElem.innerHTML += " --- Fel";
} // End matchRE
