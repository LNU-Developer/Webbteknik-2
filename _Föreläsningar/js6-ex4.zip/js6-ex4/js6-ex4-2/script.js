// JavaScript Document

// Globala variabler
var formElem;	// Referens till formuläret
var msgElem;	// Referens till elementet för meddelanden
var re;			// Array med reguljära uttryck för fälten
var errMsg;		// Array med felmeddelanden

// Initiera globala variabler och koppla funktion till knapp
function init() {
	formElem = document.getElementById("contactForm");
	msgElem = document.getElementById("message");
	addListener(formElem.name,"blur",checkName);
	addListener(formElem.address,"blur",checkAddress);
	addListener(formElem.zipcode,"blur",checkZipcode);
	addListener(formElem.town,"blur",checkTown);
	addListener(formElem.tel,"blur",checkTel);
	addListener(formElem,"submit",checkForm);
	formElem.reset();
	re = [
		/^[A-ZÅÄÖ]+((-| )[A-ZÅÄÖ]+)*$/i,		// Namn
		/^[A-ZÅÄÖ]+((-| )[A-ZÅÄÖ0-9]+)*$/i,		// Adress
		/^\d{3} ?\d{2}$/,						// Postnummer
		/^[A-ZÅÄÖ]+((-| )[A-ZÅÄÖ]+)*$/i,		// Ort
		/^0\d{1,3}[-/ ]?\d{5,8}$/				// Telefonnummer
	];
	errMsg = [
		"Namnet får endast innehålla bokstäverna a-ö, bindestreck och blanktecken.",
		"Adressen får endast innehålla bokstäverna a-ö, siffror, bindestreck och blanktecken.",
		"Postnumret måste bestå av fem siffror.",
		"Orten får endast innehålla bokstäverna a-ö, bindestreck och blanktecken.",
		"Telnr måste börja med en 0:a och sedan 6-11 siffror."
	];
} // End init
addListener(window,"load",init);

// Kontrollera fältet för namn.
function checkName() {
	checkField(formElem.name,0);
} // End checkName

// Kontrollera fältet för adress
function checkAddress() {
	checkField(formElem.address,1);
} // End checkAddress

// Kontrollera fältet för postnummer
function checkZipcode() {
	checkField(formElem.zipcode,2);
} // End checkZipcode

// Kontrollera fältet för ort.
function checkTown() {
	checkField(formElem.town,3);
} // End checkTown

// Kontrollera fältet för telefonnummer
function checkTel() {
	checkField(formElem.tel,4);
} // End checkTel

// Kontrollera innehållet i theField. index används till reguljärt uttryck och felmeddelande.
function checkField(theField,index) {
	var errMsgElem; // Referens till andra span-elementet
	errMsgElem = theField.parentNode.parentNode.getElementsByTagName("span")[1];
	errMsgElem.innerHTML = "";
	if (!re[index].test(theField.value)) {
		errMsgElem.innerHTML = errMsg[index];
		return false;
	}
	else return true;
} // checkField

// Kontrollera att formulärets innehåll är OK. Skicka i så fall iväg det.
function checkForm(e) {
	var allOK;		// Flagga för att indikera om allt är OK eller ej
	// Kontroll endast av obligatoriska fält
	if (checkField(formElem.name,0) && checkField(formElem.tel,4)) allOK = true;
	else allOK = false;
	if (formElem.msg.value == "") {
		msgElem.innerHTML = "Alla obligatoriska fält måste vara ifyllda.";
		allOK = false;
	}
	if (!allOK) e.preventDefault();
} // End checkForm