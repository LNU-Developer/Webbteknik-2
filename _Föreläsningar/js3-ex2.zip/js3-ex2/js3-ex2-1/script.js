// JavaScript

// Globala variabler
var input1Elem; // Referens till input-taggen för textfäkltet
var resultElem; // Referens till div-elementet för resultat

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	input1Elem = document.getElementById("input1");
	resultElem = document.getElementById("result");
	document.getElementById("runBtn").onclick = checkText;
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Test av olika egenskaper och metoder för strängar
function checkText() {
	var theText; // Texten från textfältet
	var textArr; // Array då textsträngen delas upp i delar
	var i; // Index till delsträng
	
	theText = input1Elem.value; // Avläs textfältet
	
	resultElem.innerHTML = "<p>Antal tecken: " + theText.length + "</p>";
		// Egenskapen length ger antal tecken i textsträngen
	
	resultElem.innerHTML += "<p>Första tecknet: " + theText.charAt(0) + "<br>Sista tecknet: " + theText.charAt(theText.length-1) + "</p>";
		// Funktionen charAt används för att avläsa ett enskilt tecken
	
	resultElem.innerHTML += "<p>Strängen i pos. 4 till 12: " + theText.substring(4,12) + "</p>";
		// Med funktionen substring får man en delsträng. Första parametern är var den börjar och sista parameterna är var den slutar
	
	resultElem.innerHTML += "<p>Bara stora bokstäver: " + theText.toUpperCase() + "</p>";
		// Med funktionen toUpperCase konverteras alla bokstäver i textsträngen till stora bokstäver
	
	resultElem.innerHTML += "<p>Bara små bokstäver: " + theText.toLowerCase() + "</p>";
		// Med funktionen toLowerCase konverteras alla bokstäver i textsträngen till små bokstäver
	
	i = theText.indexOf("text"); // Sök efter "text" i strängvariabeln theText
		// Resultatet blir positionen där "text" börjar. Om "text" ej finns i variabeln, blir resultatet -1.
	if (i == -1) resultElem.innerHTML += "<p>Ordet 'text' ingår ej.</p>";
	else resultElem.innerHTML += "<p>Ordet 'text' finns i position " + i + ".</p>";
	
	// Ersätt flera blanktecken intill varandra med ett blanktecken
	theText = theText.trim(); // Ta bort blanktecken i början och slutet av texten
	i = theText.indexOf("  "); // Sök efter tå blanktecken intill varandra
	while (i >= 0) {
		theText = theText.substring(0,i) + theText.substring(i+1); // Ta bort det första av de två blanktecknen
		i = theText.indexOf("  "); // Sök igen efter två blanktecken intill varandra
	}
	input1Elem.value = theText; // Lägg in den nya texten i textfältet
	
	textArr = theText.split(" "); // Dela upp i en array. Skiljetecknet är i detta fall ett blanktecken, så det blir en array med ord i texten
	resultElem.innerHTML += "<p>Antal ord åtskiljda av blanktecken: " + textArr.length; + "</p>";
	
	// Följande är en metod för Array, men resultatet blir en textsträng
	resultElem.innerHTML += "<p>Blanktecken ersatt av '_': " + textArr.join("_"); + "</p>";
		// Med join sätter man samman en array till en textsträng. Det tecken som läggs in mellan de olika delarna är i detta fall _
		// Funktionen join är alltså motsatsen till split
} // End checkText