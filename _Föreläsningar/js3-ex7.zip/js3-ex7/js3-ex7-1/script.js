// JavaScript

// Globala variabler
var uWord; // Lista (Array) med referenser till osorterade ord
var sWord; // Lista (Array) med referenser till sorterade ord

// Initiering av globala variabler och koppling avfunktioner till bilder
function init() {
	var i; // Loopvariabel
	uWord = document.getElementById("unsortedWords").getElementsByTagName("p");
	for (i=0; i<uWord.length; i++) uWord[i].onclick = uWordMove;
	sWord = document.getElementById("sortedWords").getElementsByTagName("p");
	for (i=0; i<sWord.length; i++) sWord[i].onclick = sWordMove;
	document.getElementById("newBtn").onclick = newWords;
	newWords();
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Klick på ord i uWord. Flytta ordet till sWord.
function uWordMove() {
	var i;	// Loopvariabel
	if (this.innerHTML == "&nbsp;") return;
	for (i=0; i<sWord.length; i++) { // Hitta första lediga position i sWord
		if (sWord[i].innerHTML == "&nbsp;") break; // Bryt loopen. i är index för första lediga pos.
	}
	sWord[i].innerHTML = this.innerHTML;
	this.innerHTML = "&nbsp;";
} // End uWordMove

// Klick på ord i sWord. Flytta ordet till uWord.
function sWordMove() {
	var i;	// Loopvariabel
	if (this.innerHTML == "&nbsp;") return;
	for (i=0; i<uWord.length; i++) { // Hitta första lediga position
		if (uWord[i].innerHTML == "&nbsp;") break; // Bryt loopen. i är index för första lediga pos.
	}
	uWord[i].innerHTML = this.innerHTML;
	// Alla ord under den som flyttas, skiftas ett steg uppåt
	for (i=0; i<sWord.length; i++) { // Leta reda på ordet man klickade på
		if (this.innerHTML == sWord[i].innerHTML) break; // Bryt loopen. i är pos. för det ord man klickat på.
	}
	for (i=i+1; i<sWord.length; i++) { // Skifta uppåt
		sWord[i-1].innerHTML = sWord[i].innerHTML;
	}
	sWord[sWord.length-1].innerHTML = "&nbsp;";
} // End sWordMove

// Generera en ny lista av slumpmässigt valda ord
function newWords() {
	var i;			// Loopvariabel
	var wordList;	// Lista med ord där man väljer några slumpmässigt
	var ix;			// Slumptal som är index till wordList
	wordList = ["Apa","Björn","Elefant","Fisk","Fjäril","Fågel","Får","Get","Giraff",
		"Gris","Hare","Hjort","Hund","Häst","Igelkott","Katt","Ko","Krokodil","Lejon",
		"Mask","Mus","Myra","Orm","Räv","Snigel","Spindel","Tiger","Varg","Älg"];
	for (i=0; i<uWord.length; i++) {
		ix = Math.floor(wordList.length*Math.random());
		uWord[i].innerHTML = wordList[ix];
		wordList.splice(ix,1);
		sWord[i].innerHTML = "&nbsp;"
	}
} // End newWords