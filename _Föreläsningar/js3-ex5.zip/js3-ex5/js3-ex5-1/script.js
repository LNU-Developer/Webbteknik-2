// JavaScript

// Globala variabler
var input1Elem; // Referens till input-taggen för textfältet
var resultElem; // Referens till div-elementet för resultat
var weekday;   // Array med veckodagar
var month;     // Array med månader
var today;     // Datum-objekt för dagens datum

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	var w, d, m, y; // Veckodag, månadsdag, månad och år
	input1Elem = document.getElementById("input1");
	resultElem = document.getElementById("result");
	document.getElementById("runBtn").onclick = xmasEveDay;
	weekday = ["söndag","måndag","tisdag","onsdag","torsdag","fredag","lördag"];
		// Börja med söndag, som får index 0, eftersom dagnummer som man får ur Date-objektet börjar på 0 för söndag
	month = ["januari","februari","mars","april","maj","juni","juli","augusti","september","oktober","november","december"];
		// Index 0 till 11, som är samma nummer som månaderna har i Dqte-objektet
	today = new Date(); // Skapa ett objekt för dagens datum
	w = today.getDay(); // Veckans dag (0-6)
	d = today.getDate(); // Månadens dag (1-31)
	m = today.getMonth(); // Månad (0-11)
	y = today.getFullYear(); // År med fyra siffror
	document.getElementById("dateToday").innerHTML = weekday[w] + " den " + d + " " + month[m] + " " + y;
	 // Skriv ut veckodag på sidan i taggen med id="day"
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Ta fram veckodag för angiven julafton samt beräkna hur många dagar det är kvar dit
function xmasEveDay() {
	var w; // Veckodag
	var year; // År som avläses ur textfäletet
	var xmasEve; // Date-objekt för julafton valt år
	var daysCount; // Antal dagar som återstår
	year = Number(input1Elem.value);
	xmasEve = new Date(year,11,24); // Skapa ett datumobjekt för julafton det angivna året
		// Parametrarna är år, månad, dag. Obs! månad är 0-11, så 11 är december
	w = xmasEve.getDay(); //Veckodag för julafton
	resultElem.innerHTML = "<p>År " + year + " är julafton på en " + weekday[w] + "</p>";
	
	daysCount = Math.round((xmasEve.getTime() - today.getTime()) / (1000*60*60*24));
		// Beräkna hur många dagar det är kvar
		// getTime() ger tid i millisekunder från den 1 januari 1970
		// Skillnaden blir hur många millisekunder som återstår
		// Dividera med 1000 för att få sekunder, med 60 för minuter, med 60 igen för timmar och med 24 för dagar
		
	resultElem.innerHTML += "<p>Det är " + daysCount + " dagar kvar</p>";
} // End xmasEveDay