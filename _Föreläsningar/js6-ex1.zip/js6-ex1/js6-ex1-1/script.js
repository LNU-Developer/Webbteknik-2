// JavaScript Document

// Globala variabler
var formElem;	// Referens till formuläret
var msgElem;	// Referens till element för meddelanden

// Initiera globala variabler och koppla funktion till knapp
function init() {
	formElem = document.getElementById("theForm");
	msgElem = document.getElementById("message");
	addListener(formElem.testBtn,"click",readForm);
} // End init
addListener(window,"load",init);

// Testfunktion för att avläsa innehåll ur formuläret
function readForm() {
	var i; // Loopvariabel
	var t1, t2, c1, c2, c3, s3; // Lokala variabler där formulärets innehåll sparas
	
	// Textfälten
	t1 = formElem.text1.value;
	t2 = formElem.text2.value;
	
	// Radioknapparna
	c1 = "";
	for (i=0; i<formElem.choice1.length; i++) {
		if (formElem.choice1[i].checked) c1 = formElem.choice1[i].value;
	}
	
	// Kryssrutorna
	c2 = "";
	for (i=0; i<formElem.choice2.length; i++) {
		if (formElem.choice2[i].checked) c2 += formElem.choice2[i].value + " ";
	}
	
	// Menyn
	s3 = formElem.choice3.selectedIndex;
	c3 = formElem.choice3.options[s3].value;
	
	// Skriv ut alla val
	msgElem.innerHTML = "Text 1: " + t1 + "<br>Text 2: " + t2 +
			"<br>Radioknapparna: " + c1 + "<br>Kryssrutorna: " + c2 +
			"<br>Menyn, valt värde: " + c3 + "<br>Menyn, valt alternativ: " + s3;
} // End readForm
