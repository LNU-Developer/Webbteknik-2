// JavaScript Document

// Globala variabler
var formElem;	// Referens till formuläret

// Initiera globala variabler och koppla funktion till knapp
function init() {
	formElem = document.getElementById("navForm");
	addListener(formElem.shortcutMenu,"change",gotoShortcut);
} // End init
addListener(window,"load",init);

// Gå till den sida som valts i menyn
function gotoShortcut() {
	var newUrl;	// Adress till vald sida
	newUrl = formElem.shortcutMenu.options[formElem.shortcutMenu.selectedIndex].value;
	location.href = newUrl;
} // End gotoShortcut
