// JavaScript Document

// Globala variabler
var formElem;	// Referens till formuläret
var msgElem;	// Referens till element för meddelanden

// Initiera globala variabler och koppla funktion till knapp
function init() {
	formElem = document.getElementById("theForm");
	msgElem = document.getElementById("message");
	
	addListener(formElem.text1,"focus",fieldFocus);
	addListener(formElem.text2,"focus",fieldFocus);
	addListener(formElem.text1,"blur",fieldBlur);
	addListener(formElem.text2,"blur",fieldBlur);
	addListener(formElem.text1,"change",fieldChange);
	addListener(formElem.text2,"change",fieldChange);
	
	addListener(formElem.choice3,"change",menuChange);
	addListener(formElem.choice3,"mousedown",menuMouseDown);
	
	addListener(formElem,"submit",checkForm);
	
	formElem.reset();
} // End init
addListener(window,"load",init);

// Användaren har klickat iett textfält
function fieldFocus() {
	this.style.backgroundColor = "white";
	this.select();
} // End fieldFocus

// Användaren lämnar textfältet
function fieldBlur() {
	this.parentNode.parentNode.getElementsByTagName("span")[0].innerHTML = 
		this.value.length + " tecken";
} // End fieldBlur

// Innehållet i textfältet har ändrats
function fieldChange() {
	this.style.backgroundColor = "yellow";
} // End fieldChange

// Användaren trycker ner musknappen över en meny, dvs menyn tas fram
function menuMouseDown() {
	msgElem.innerHTML = "";
} // End menuMouseDown

// Ett nytt alternativ har valts i menyn
function menuChange() {
	msgElem.innerHTML = "Du valde en ny dag.";
} // End menuChange

// Kontrollera att formulärets innehåll är OK. Skicka i så fall iväg det.
function checkForm(e) {
	// Antag att det måste stå något i det första textfältet
	// och att minst en frukt ska vara vald i kryssrutorna
	var noFruits;	// Flagga, för att avgöra om formuläret ska skickas
	var i;			// Loopvariabel
	msgElem.innerHTML = "";
	if (formElem.text1.value == "") {
		msgElem.innerHTML += "<p>Det första textfältet måste innehålla någon text.</p>";
		e.preventDefault();
	}
	noFruits = true;
	for (i=0; i<formElem.choice2.length; i++) {
		if (formElem.choice2[i].checked) noFruits = false;
	}
	if (noFruits) {
		msgElem.innerHTML += "<p>Du måste välja åtminstone en frukt.</p>";
		e.preventDefault();
	}
} // End checkForm