// JavaScript Document

// Globala variabler
var timerRef;	// Referens till timern (den interna tidsräknaren som startas med setTimeOut)
var timeStep;	// Tiden mellan varje uppdatering av räknaren
var counter;	// Tidsräknare som ska räknas ner

// Initiera globala variabler och koppla funktion till knapp
function init() {
	var i;	// Loopvariabel
	inputTimeElem = document.getElementById("inputTime");
	timeBoxElem = document.getElementById("timeBox");
	addListener(document.getElementById("startBtn"),"click",startTimer);
	addListener(document.getElementById("stopBtn"),"click",stopTimer);
	timerRef = null;
	timeStep = 100; // 100 ms
} // End init
addListener(window,"load",init);

// Funktion för knappen som startar timern
function startTimer() {
	counter = 1000*Number(inputTimeElem.value);
	updateCounter();
} // End startTimer

// Uppdatera räknaren på sidan och starta en timer för nästa anrop av funktionen
function updateCounter() {
	counter -= timeStep;
	timeBoxElem.innerHTML = (counter/1000).toFixed(1);
	if (counter > 0) timerRef = setTimeout(updateCounter,timeStep);
	else timerRef = null;
} // End updateCounter

// Funktion för knappen som stoppar timern
function stopTimer() {
	if (timerRef != null) clearTimeout(timerRef);
	else alert("Du måste först starta tidsräknaren");
} // End stopTimer