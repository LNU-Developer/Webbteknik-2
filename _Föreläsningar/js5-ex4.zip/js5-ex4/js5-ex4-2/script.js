// JavaScript Document

// Globala variabler
var cardElems;	// Array med referenser till korten
var cardIx;		// Index till det kort som ligger främst
var timerRef;	// Referens till timern (den interna tidsräknaren som startas med setTimeOut)

// Initiera globala variabler och koppla funktion till knapp
function init() {
	var i;	// Loopvariabel
	cardElems = document.getElementById("cards").getElementsByTagName("div");
	for (i=0; i<cardElems.length; i++) {
		cardElems[i].style.left = 60*i+"px";
		cardElems[i].style.top = 20*i + "px";
	}
	cardIx = 0;
	updateCards();
	addListener(document.getElementById("leftBtn"),"click",browseLeft);
	addListener(document.getElementById("rightBtn"),"click",browseRight);
	timerRef = setTimeout(timerBrowse,8000); // Börja efter 8 sekunder
} // End init
addListener(window,"load",init);

// Bläddra automatisk, byt kort var tredje sekund
function timerBrowse() {
	if (cardIx < cardElems.length-1) cardIx++;
	else cardIx = 0;
	updateCards();
	timerRef = setTimeout(timerBrowse,3000);
} // End timerBrowse

// Bläddra åt vänster
function browseLeft() {
	if (timerRef != null) clearTimeout(timerRef);
	if (cardIx > 0) cardIx--;
	updateCards();
	timerRef = setTimeout(timerBrowse,8000);
} // End browseLeft

// Bläddra åt höger
function browseRight() {
	if (timerRef != null) clearTimeout(timerRef);
	if (cardIx < cardElems.length-1) cardIx++;
	updateCards();
	timerRef = setTimeout(timerBrowse,8000);
} // End browseRight

// Lägg aktuellt kort längst fram och justera ordning för övriga kort
function updateCards() {
	var i;	// Loopvariabel
	var z;	// Nya värden på z-index
	// Kortet som ska ligga längst fram
	z = 100;
	cardElems[cardIx].style.backgroundColor = "#FC6";
	cardElems[cardIx].style.zIndex = z;
	// Alla kort till vänster
	z = 99;
	for (i=cardIx-1; i>=0; i--) {
		cardElems[i].style.backgroundColor = "#FFC";
		cardElems[i].style.zIndex = z--;
	}
	// Alla kort till höger
	z = 99;
	for (i=cardIx+1; i<cardElems.length; i++) {
		cardElems[i].style.backgroundColor = "#FFC";
		cardElems[i].style.zIndex = z--;
	}
} // End updateCards