// JavaScript

// Globala variabler
var imgElem;		// Referens till img-elementet för bilden i bildspelet
var currentPictNr;	// Nummer för aktuell bild

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	imgElem = document.getElementById("thePict");
	document.getElementById("firstBtn").onclick = function() {changePict(1)};
	document.getElementById("prevBtn").onclick = prevPict;
	document.getElementById("nextBtn").onclick = nextPict;
	document.getElementById("lastBtn").onclick = function() {changePict(4)};
	currentPictNr = 1;  // Bild 1 är den som finns i img-elementet i HTML-koden
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

function changePict(pictNr) {
	imgElem.src = "pics/church" + pictNr + ".jpg";
	currentPictNr = pictNr;
} // End changePict

function prevPict() {
	if (currentPictNr > 1) changePict(currentPictNr-1);
} // End prevPict

function nextPict() {
	if (currentPictNr < 4) changePict(currentPictNr+1);
} // End nextPict
