// JavaScript

alert("Nu är js-filen inläst.");