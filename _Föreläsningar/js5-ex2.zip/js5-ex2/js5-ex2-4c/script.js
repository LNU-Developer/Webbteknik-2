// JavaScript Document

// Globala variabler

// Initiera globala variabler och koppla funktion till knapp
function init() {
	var i;			// Loopvariabel
	var menuElems;	// Array med referenser till elementen med menytitel och meny
	menuElems = document.getElementsByClassName("menu");
	for (i=0; i<menuElems.length; i++) {
		addListener(menuElems[i],"mouseover",showMenu);
		addListener(menuElems[i],"mouseout",hideMenu);
	}
} // End init
addListener(window,"load",init);

// Visa undermenyn
function showMenu() {
	var thisMenu;	// Referens till undermenyn
	thisMenu = this.getElementsByTagName("ul")[0];
	thisMenu.style.visibility = "visible";
} // End showMenu

// Dölj undermenyn
function hideMenu() {
	var thisMenu;	// Referens till undermenyn
	thisMenu = this.getElementsByTagName("ul")[0];
	thisMenu.style.visibility = "hidden";
} // End hideMenu
