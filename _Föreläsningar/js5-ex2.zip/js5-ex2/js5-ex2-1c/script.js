// JavaScript Document

// Globala variabler
var menuTitleElems;	// Array med referenser till menytitlarna
var submenuElems;	// Array med referenser till undermenyerna

// Initiera globala variabler och koppla funktion till knapp
function init() {
	var i;			// Loopvariabel
	var menusElem;	// Referens till elementet som omger alla menyer
	menusElem = document.getElementById("menus");
	menuTitleElems = menusElem.getElementsByTagName("span");
	submenuElems = menusElem.getElementsByClassName("submenu");
	for (i=0; i<menuTitleElems.length; i++) {
		addListener(menuTitleElems[i],"click",showHideMenu);
	}
} // End init
addListener(window,"load",init);

// Om menyn visas, så döljs den, annars visas den
function showHideMenu() {
	var i;			// Loopvariabel
	var thisMenu;	// Referens till undermenyn
	var show;		// Flagga (true/false) för att markera om menyn ska visas eller döljas
	thisMenu = this.parentNode.getElementsByTagName("ul")[0];
	if (thisMenu.style.display == "block") show = false;
	else show = true;
	for (i=0; i<submenuElems.length; i++) {
		submenuElems[i].style.display = "none";
	}
	if (show) thisMenu.style.display = "block";
} // End showHideMenu
