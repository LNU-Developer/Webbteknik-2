// JavaScript

// Skriv ut dagens datum på webbsidan
function displayTodaysDate() {
	var weekday;   // Array med veckodagar
	var month;     // Array med månader
	var today;     // Datum-objekt för dagens datum
	var w, d, m, y; // Veckodag, månadsdag, månad och år
	weekday = ["Söndag","Måndag","Tisdag","Onsdag","Torsdag","Fredag","Lördag"];
	month = ["januari","februari","mars","april","maj","juni","juli","augusti","september","oktober","november","december"];
	today = new Date(); // Skapa ett objekt för dagens datum
	w = today.getDay(); // Veckans dag (0-6)
	d = today.getDate(); // Månadens dag (1-31)
	m = today.getMonth(); // Månad (0-11)
	y = today.getFullYear(); // År med fyra siffror
	document.getElementById("dateToday").innerHTML = weekday[w] + " den " + d + " " + month[m] + " " + y;
} // End displayTodaysDate
//window.addEventListener("load",displayTodaysDate);
addListener(window,"load",displayTodaysDate);
