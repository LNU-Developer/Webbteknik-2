// JavaScript Document

// Lägg till en händelsehanterare
// obj är elementet, type är händelsen och fn är funktionen
function addListener(obj, type, fn) {
	if (obj.addEventListener) obj.addEventListener(type,fn);
	else obj.attachEvent("on"+type,fn);
} // End addListener