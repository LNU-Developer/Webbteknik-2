// JavaScript Document

// Globala variabler
var cardElems;		// Array med referenser till img-elementen för korten
var cards;			// Array med alla kortvalörer
var newBtn, chgBtn;	// Referenser till de båda knapparna

// Initiera globala variabler och koppla funktion till knapp
function init() {
	cardElems = document.getElementById("cards").getElementsByTagName("img");
	newBtn = document.getElementById("newBtn");
	chgBtn = document.getElementById("chgBtn");
	addListener(newBtn,"click",newCards);
	addListener(chgBtn,"click",changeCards);
	newBtn.disabled = false;
	chgBtn.disabled = true;
} // End init
addListener(window,"load",init);

// Ny kortlek och dra fem kort
function newCards() {
	var i;	// Loopvariabel
	cards = ["c1","c2","c3","c4","c5","c6","c7","c8","c9","c10","cj","cq","ck",
			 "d1","d2","d3","d4","d5","d6","d7","d8","d9","d10","dj","dq","dk",
			 "h1","h2","h3","h4","h5","h6","h7","h8","h9","h10","hj","hq","hk",
			 "s1","s2","s3","s4","s5","s6","s7","s8","s9","s10","sj","sq","sk"];
	for (i=0; i<cardElems.length; i++) {
		oneCard(cardElems[i]);
	}
	newBtn.disabled = true;
	chgBtn.disabled = false;
	for (i=0; i<cardElems.length; i++) {
		addListener(cardElems[i],"click",flipCard);
	}
} // End newCards

// Vänd på det kort som användaren klickat på
function flipCard() {
	this.src = "pics/backside.png";
} // End changeCard

// Dra nya kort för de som är vända
function changeCards() {
	var i;	// Loopvariabel
	for (i=0; i<cardElems.length; i++) {
		if (cardElems[i].src.indexOf("backside") != -1) oneCard(cardElems[i]);
	}
	newBtn.disabled = false;
	chgBtn.disabled = true;
	for (i=0; i<cardElems.length; i++) {
		removeListener(cardElems[i],"click",flipCard);
	}
} // End changeCards

// Generera ett slumptal mellan 0 och antal kort som finns kvar i cards.
// Bestäm ny url utifrån talet och visa bilden för kortet.
function oneCard(elem) { // elem är referens till img-elementet för kortet
	var cardIndex; // Index till arrayen med alla kort
	cardIndex = Math.floor(cards.length*Math.random());
	elem.src = "pics/" + cards[cardIndex] + ".png";
	cards.splice(cardIndex,1)
} // End oneCard