// JavaScript Document

// Globala variabler
var formElem;	// Referens till formuläret

// Initiera globala variabler och koppla funktion till knapp
function init() {
	formElem = document.getElementById("theForm");
	addListener(formElem.saveBtn,"click",saveMyCookie);
	getMyCookie();
} // End init
addListener(window,"load",init);

// Spara formulärets innehåll i cookien.
function saveMyCookie() {
	var cookieValue;	// Textsträng för cookiens innehåll
	cookieValue = escape(formElem.theText.value);
	setCookie("testCookie1",cookieValue);
} // End saveMyCookie

// Hämta cookien och fyll formuläret med dess innehåll.
function getMyCookie() {
	var cookieValue;	// Textsträng för cookiens innehåll
	cookieValue = getCookie("testCookie1");
	if (cookieValue != null) {
		formElem.theText.value = unescape(cookieValue);
	}
} // End getMyCookie
