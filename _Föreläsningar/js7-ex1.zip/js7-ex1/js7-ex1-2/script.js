// JavaScript Document

// Globala variabler
var counter;	// Besöksräknare för användaren.

// Initiera globala variabler
function init() {
	counterElem = document.getElementById("counterInfo");
	counter = 0;
	getMyCookie();
	counter++;
	counterElem.innerHTML = "Det här är besök nummer " + counter + " på denna sida.";
} // End init
addListener(window,"load",init);
addListener(window,"unload",saveMyCookie);

// Spara räknaren i cookien.
function saveMyCookie() {
	setCookie("testCookie2",counter);
} // End saveMyCookie

// Hämta cookien och lägg in den i counter, ifall cookien finns.
function getMyCookie() {
	var cookieValue;	// Textsträng för cookiens innehåll
	cookieValue = getCookie("testCookie2");
	if (cookieValue != null) {
		counter = Number(cookieValue);
	}
} // End getMyCookie
