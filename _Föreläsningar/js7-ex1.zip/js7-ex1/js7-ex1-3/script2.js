// JavaScript Document

// Globala variabler
var resElem;	// Referens till element för resultat

// Initiera globala variabler och koppla funktion till knapp
function init() {
	resElem = document.getElementById("result");
	getMyCookie();
} // End init
addListener(window,"load",init);

// Hämta cookien och skriv ut dess innehåll på sidan, ifall cookien finns.
function getMyCookie() {
	var i;				// Loopvariabel
	var cookieValue;	// Textsträng för cookiens innehåll
	var cookieArr;		// Array då textsträngen delas vid skiljetecknen
	cookieValue = getCookie("testCookie3");
	if (cookieValue != null) {
		cookieArr = cookieValue.split("#");
		for (i=0; i<cookieArr.length; i++) {
			resElem.innerHTML += "<p>" + unescape(cookieArr[i]) + "</p>";
		}
	}
} // End getMyCookie
