// JavaScript Document

// Globala variabler
var formElem;	// Referens till formuläret

// Initiera globala variabler och koppla funktion till knapp
function init() {
	formElem = document.getElementById("theForm");
	addListener(formElem.nextBtn,"click",nextPage);
	getMyCookie();
} // End init
addListener(window,"load",init);
addListener(window,"unload",saveMyCookie);

// Gå till nästa sida.
function nextPage() {
	location.href = "page2.htm";
} // End nextPage

// Spara formulärets innehåll i cookien.
function saveMyCookie() {
	var i;				// Loopvariabel
	var cookieValue;	// Textsträng för cookiens innehåll
	cookieValue = "";
	for (i=0; i<formElem.theText.length; i++) {
		cookieValue += "#" + escape(formElem.theText[i].value);
	}
	cookieValue = cookieValue.substring(1); // Ta bort det första #-tecknet, dvs behåll alla tecken från pos. 1 och framåt
	setCookie("testCookie3",cookieValue);
} // End saveMyCookie

// Hämta cookien och fyll formuläret med dess innehåll, ifall cookien finns.
function getMyCookie() {
	var i;				// Loopvariabel
	var cookieValue;	// Textsträng för cookiens innehåll
	var cookieArr;		// Array då textsträngen delas vid skiljetecknen
	cookieValue = getCookie("testCookie3");
	if (cookieValue != null) {
		cookieArr = cookieValue.split("#");
		for (i=0; i<cookieArr.length; i++) {
			formElem.theText[i].value = unescape(cookieArr[i]);
		}
	}
} // End getMyCookie
