// JavaScript Document

// Globala variabler
var boxElem;		// Referens till boxen som ska glida in
var contactBtn;		// Referens till kontakt-knappen
var fadeTimerRef;	// Referens till timern

// Initiera globala variabler och koppla funktion till knapp
function init() {
	boxElem = document.getElementById("contactForm");
	contactBtn = document.getElementById("contactBtn");
	addListener(contactBtn,"click",fadeBox);
	fadeTimerRef = null;
	boxElem.style.opacity = 0;
} // End init
addListener(window,"load",init);

// Starta en upptoning eller nedtoning
function fadeBox() {
	if (fadeTimerRef != null) clearTimeout(fadeTimerRef);
	if (contactBtn.innerHTML == "Kontakta oss ...") {
		boxElem.style.visibility = "visible";
		fadeIn();
		contactBtn.innerHTML = "Dölj formuläret";
	}
	else {
		fadeOut();
		contactBtn.innerHTML = "Kontakta oss ...";
	}
} // End fadeBox

// Tona ett steg uppåt
function fadeIn() {
	var op;	// Aktuell opacity för boxen
	op = Number(boxElem.style.opacity);
	if (op < 1) {
		boxElem.style.opacity = op+0.05;
		fadeTimerRef = setTimeout(fadeIn,50);
	}
} // End fadeIn

// Tona ett steg nedåt
function fadeOut() {
	var op;	// Aktuell opacity för boxen
	op = Number(boxElem.style.opacity);
	if (op > 0) {
		boxElem.style.opacity = op-0.05;
		fadeTimerRef = setTimeout(fadeOut,50);
	}
	else {
		boxElem.style.visibility = "hidden";
	}
} // End fadeOut
