// JavaScript Document

// Globala variabler
var boxElem;	// Referens till boxen som ska glida in
var contactBtn;		// Referens till kontakt-knappen
var slideTimerRef;	// Referens till timern

// Initiera globala variabler och koppla funktion till knapp
function init() {
	boxElem = document.getElementById("contactForm");
	contactBtn = document.getElementById("contactBtn");
	addListener(contactBtn,"click",slideBox);
	slideTimerRef = null;
	boxElem.style.left = "-300px";
} // End init
addListener(window,"load",init);

// Strata en glidning inåt eller utåt
function slideBox() {
	if (slideTimerRef != null) clearTimeout(slideTimerRef);
	if (contactBtn.innerHTML == "Kontakta oss ...") {
		slideIn();
		contactBtn.innerHTML = "Dölj formuläret";
	}
	else {
		slideOut();
		contactBtn.innerHTML = "Kontakta oss ...";
	}
} // End slideBox

// Glid ett steg inåt
function slideIn() {
	var x;	// Aktuell left-koordinat för boxen
	x = parseInt(boxElem.style.left);
	if (x < 0) {
		boxElem.style.left = (x+2) + "px";
		slideTimerRef = setTimeout(slideIn,5);
	}
} // End slideIn

// Glid ett steg utåt
function slideOut() {
	var x;	// Aktuell left-koordinat för boxen
	x = parseInt(boxElem.style.left);
	if (x > -300) {
		boxElem.style.left = (x-2) + "px";
		slideTimerRef = setTimeout(slideOut,5);
	}
} // End slideOut
