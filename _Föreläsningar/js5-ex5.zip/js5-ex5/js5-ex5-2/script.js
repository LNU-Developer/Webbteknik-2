// JavaScript Document

// Globala variabler
var boxElem;	// Referens till boxen som ska glida in
var contactBtn;		// Referens till kontakt-knappen
var zoomTimerRef;	// Referens till timern

// Initiera globala variabler och koppla funktion till knapp
function init() {
	boxElem = document.getElementById("contactForm");
	contactBtn = document.getElementById("contactBtn");
	addListener(contactBtn,"click",zoomBox);
	zoomTimerRef = null;
	boxElem.style.width = "0px";
	boxElem.style.height = "0px";
} // End init
addListener(window,"load",init);

// Starta en zoomning uppåt eller nedåt
function zoomBox() {
	if (zoomTimerRef != null) clearTimeout(zoomTimerRef);
	if (contactBtn.innerHTML == "Kontakta oss ...") {
		boxElem.style.visibility = "visible";
		zoomUp();
		contactBtn.innerHTML = "Dölj formuläret";
	}
	else {
		zoomDown();
		contactBtn.innerHTML = "Kontakta oss ...";
	}
} // End zoomBox

// Zooma ett steg uppåt
function zoomUp() {
	var w;	// Aktuell bredd för boxen
	w = parseInt(boxElem.style.width);
	if (w < 260) {
		boxElem.style.width = (w+4) + "px";
		boxElem.style.height = (w+4) + "px";
		zoomTimerRef = setTimeout(zoomUp,5);
	}
} // End zoomUp

// Zooma ett steg nedåt
function zoomDown() {
	var w;	// Aktuell bredd för boxen
	w = parseInt(boxElem.style.width);
	if (w > 0) {
		boxElem.style.width = (w-4) + "px";
		boxElem.style.height = (w-4) + "px";
		zoomTimerRef = setTimeout(zoomDown,5);
	}
	else {
		boxElem.style.visibility = "hidden";
	}
} // End zoomDown
