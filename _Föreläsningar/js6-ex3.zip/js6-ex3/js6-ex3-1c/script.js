// JavaScript Document

// Globala variabler
var formElem;	// Referens till formuläret
var msgElem;	// Referens till elementet för meddelanden

// Initiera globala variabler och koppla funktion till knapp
function init() {
	formElem = document.getElementById("contactForm");
	msgElem = document.getElementById("message");
	addListener(formElem.name,"blur",checkName);
	addListener(formElem.address,"blur",checkAddress);
	addListener(formElem.zipcode,"blur",checkZipcode);
	addListener(formElem.town,"blur",checkTown);
	addListener(formElem.tel,"blur",checkTel);
	addListener(formElem,"submit",checkForm);
	formElem.reset();
} // End init
addListener(window,"load",init);

// Kontrollera fältet för namn.
// Namn kan endast bestå av bokstäver, bindestreck och blanktecken.
function checkName() {
	checkLegalCaracters(formElem.name,"abcdefghijklmnopqrstuvwxyzåäö- ");
} // End checkName

// Kontrollera fältet för adress
// En adress består av bokstäver, siffror, blanktecken och bindestreck.
function checkAddress() {
	checkLegalCaracters(formElem.address,"abcdefghijklmnopqrstuvwxyzåäö0123456789- ");
} // End checkAddress

// Kontrollera fältet för postnummer
// Ett postnummer består av fem siffror. Det kan också förekomma ett blanktecken, om man t.ex. skriver 123 45.
function checkZipcode() {
	var checkText;	// Text som ska kontrolleras
	var errMsgElem; // Referens till andra span-elementet
	errMsgElem = formElem.zipcode.parentNode.parentNode.getElementsByTagName("span")[1];
	checkText = formElem.zipcode.value;
	if (checkText[3] == " ") {
		checkText = checkText.substr(0,3) + checkText.substr(4); // Ta bort blanktecken i index 3
		this.value = checkText;
	}
	checkLegalCaracters(formElem.zipcode,"0123456789");
	if (checkText.length != 5) errMsgElem.innerHTML = "Ska vara fem siffror.";
} // End checkZipcode

// Kontrollera fältet för ort.
// Namn kan endast bestå av bokstäver, bindestreck och blanktecken.
function checkTown() {
	checkLegalCaracters(formElem.town,"abcdefghijklmnopqrstuvwxyzåäö- ");
} // End checkTown

// Kontrollera fältet för telefonnummer
// Telefonnumret ska bestå av endast siffror. Den första siffran ska vara en 0:a.
// Tillåtna kombinationer är att det också finns ett -, / eller blanktecken.
function checkTel() {
	var checkText;	// Text som ska kontrolleras
	var errMsgElem; // Referens till andra span-elementet
	var OKflag;		// Flagga för att markera om det är OK eller ej
	errMsgElem = formElem.tel.parentNode.parentNode.getElementsByTagName("span")[1];
	checkText = formElem.tel.value;
	OKflag = checkLegalCaracters(formElem.tel,"0123456789-/ ");
	if (checkText.charAt(0) != "0") {
		errMsgElem.innerHTML = "Måste börja med en 0:a";
		OKflag = false;
	}
	return OKflag;
} // End checkTel

// Kontrollera om textsträngen i fältet theField endast innehåller tecken som är tillåtna (legalSet).
// Eventuella felmeddelanden skrivs i span-taggen intill theField
function checkLegalCaracters(theField,legalSet) {
	var i;			// Loopvariabel
	var checkText;	// Text som ska kontrolleras
	var errMsgElem; // Referens till andra span-elementet
	errMsgElem = theField.parentNode.parentNode.getElementsByTagName("span")[1];
	errMsgElem.innerHTML = "";
	checkText = theField.value.toLowerCase();
	for (i=0; i<checkText.length; i++) {
		if (legalSet.indexOf(checkText.charAt(i)) == -1) {
			errMsgElem.innerHTML = "Felaktigt tecken: " + checkText.charAt(i);
			return false;
		}
	}
	return true;
} // End checkLegalCaracters

// Kontrollera att alla obligatoriska fält är ifyllda. Annars skickas det inte.
function checkForm(e) {
	var i;			// Loopvariabel
	var reqFields;	// Array med referenser till obligatoriska fält
	reqFields = formElem.getElementsByClassName("required");
	if (!checkTel()) {
		msgElem.innerHTML = "Telefonnumret är inte på korrekt form.";
		e.preventDefault();
	}
	for (i=0; i<reqFields.length; i++) {
		if (reqFields[i].value == "") {
			msgElem.innerHTML = "Alla obligatoriska fält måste vara ifyllda.";
			e.preventDefault();
		}
	}
} // End checkForm