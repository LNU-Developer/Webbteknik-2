// JavaScript Document

// Globala variabler
var formElem;	// Referens till formuläret
var msgElem;	// Referens till elementet för meddelanden

// Initiera globala variabler och koppla funktion till knapp
function init() {
	formElem = document.getElementById("contactForm");
	msgElem = document.getElementById("message");
	addListener(formElem.name,"blur",checkName);
	addListener(formElem.address,"blur",checkAddress);
	addListener(formElem.zipcode,"blur",checkZipcode);
	addListener(formElem.town,"blur",checkTown);
	addListener(formElem.tel,"blur",checkTel);
	addListener(formElem,"submit",checkForm);
	formElem.reset();
} // End init
addListener(window,"load",init);

// Kontrollera fältet för namn.
// Namn kan endast bestå av bokstäver, bindestreck och blanktecken.
function checkName() {
	var i;			// Loopvariabel
	var checkText;	// Text som ska kontrolleras
	var errMsgElem; // Referens till andra span-elementet
	errMsgElem = this.parentNode.parentNode.getElementsByTagName("span")[1];
	errMsgElem.innerHTML = "";
	checkText = this.value.toLowerCase();
	for (i=0; i<checkText.length; i++) {
		if ("abcdefghijklmnopqrstuvwxyzåäö- ".indexOf(checkText.charAt(i)) == -1) {
			errMsgElem.innerHTML = "Felaktigt tecken: " + checkText.charAt(i);
			break;
		}
	}
} // End checkName

// Kontrollera fältet för adress
// En adress består av bokstäver, siffror, blanktecken och bindestreck.
function checkAddress() {
	var i;			// Loopvariabel
	var checkText;	// Text som ska kontrolleras
	var errMsgElem; // Referens till andra span-elementet
	errMsgElem = this.parentNode.parentNode.getElementsByTagName("span")[1];
	errMsgElem.innerHTML = "";
	checkText = this.value.toLowerCase();
	for (i=0; i<checkText.length; i++) {
		if ("abcdefghijklmnopqrstuvwxyzåäö0123456789- ".indexOf(checkText.charAt(i)) == -1) {
			errMsgElem.innerHTML = "Felaktigt tecken: " + checkText.charAt(i);
			break;
		}
	}
} // End checkAddress

// Kontrollera fältet för postnummer
// Ett postnummer består av fem siffror. Det kan också förekomma ett blanktecken, om man t.ex. skriver 123 45.
function checkZipcode() {
	var i;			// Loopvariabel
	var checkText;	// Text som ska kontrolleras
	var errMsgElem; // Referens till andra span-elementet
	errMsgElem = this.parentNode.parentNode.getElementsByTagName("span")[1];
	errMsgElem.innerHTML = "";
	checkText = this.value;
	if (checkText[3] == " ") checkText = checkText.substr(0,3) + checkText.substr(4); // Ta bort blanktecken i index 3
	for (i=0; i<checkText.length; i++) {
		if ("0123456789".indexOf(checkText.charAt(i)) == -1) {
			errMsgElem.innerHTML = "Felaktigt tecken: " + checkText.charAt(i);
			break;
		}
	}
	if (checkText.length != 5) errMsgElem.innerHTML = "Ska vara fem siffror.";
} // End checkZipcode

// Kontrollera fältet för ort.
// Namn kan endast bestå av bokstäver, bindestreck och blanktecken.
function checkTown() {
	var i;			// Loopvariabel
	var checkText;	// Text som ska kontrolleras
	var errMsgElem; // Referens till andra span-elementet
	errMsgElem = this.parentNode.parentNode.getElementsByTagName("span")[1];
	errMsgElem.innerHTML = "";
	checkText = this.value.toLowerCase();
	for (i=0; i<checkText.length; i++) {
		if ("abcdefghijklmnopqrstuvwxyzåäö- ".indexOf(checkText.charAt(i)) == -1) {
			errMsgElem.innerHTML = "Felaktigt tecken: " + checkText.charAt(i);
			break;
		}
	}
} // End checkTown

// Kontrollera fältet för telefonnummer
// Telefonnumret ska bestå av endast siffror. Den första siffran ska vara en 0:a.
// Tillåtna kombinationer är att det också finns ett -, / eller blanktecken.
function checkTel() {
	var checkText;	// Text som ska kontrolleras
	var errMsgElem; // Referens till andra span-elementet
	errMsgElem = this.parentNode.parentNode.getElementsByTagName("span")[1];
	errMsgElem.innerHTML = "";
	checkText = this.value;
	for (i=0; i<checkText.length; i++) {
		if ("0123456789-/ ".indexOf(checkText.charAt(i)) == -1) {
			errMsgElem.innerHTML = "Felaktigt tecken: " + checkText.charAt(i);
			break;
		}
	}
	if (checkText.charAt(0) != "0") errMsgElem.innerHTML = "Måste börja med en 0:a";
} // End checkTel

// Kontrollera att alla obligatoriska fält är ifyllda. Annars skickas det inte.
function checkForm(e) {
	var i;			// Loopvariabel
	var reqFields;	// Array med referenser till obligatoriska fält
	reqFields = formElem.getElementsByClassName("required");
	for (i=0; i<reqFields.length; i++) {
		if (reqFields[i].value == "") {
			msgElem.innerHTML = "Alla obligatoriska fält måste vara ifyllda.";
			e.preventDefault();
			break;
		}
	}
} // End checkForm