// JavaScript

// Globala variabler
var input1Elem, input2Elem; // Referenser till input-taggarna
var resultElem; // Referens till div-elementet för resultat

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	input1Elem = document.getElementById("input1");
	input2Elem = document.getElementById("input2");
	resultElem = document.getElementById("result");
	document.getElementById("addBtn").onclick = add;
	document.getElementById("subBtn").onclick = sub;
	document.getElementById("multBtn").onclick = mult;
	document.getElementById("divBtn").onclick = div;
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Avläs textfälten
function getNumbers() {
	var inpNr = []; // Array med värdena som läses in från textfälten
	inpNr[0] = Number(input1Elem.value);
	inpNr[1] = Number(input2Elem.value);
	return inpNr;
} // End getNumbers

// Summera talen
function add() {
	var nr, res; // Array med input-värdena och variabel för resultat
	nr = getNumbers();
	res = nr[0] + nr[1];
	resultElem.innerHTML = res;
} // End add

// Subtrahera talen
function sub() {
	var nr, res; // Array med input-värdena och variabel för resultat
	nr = getNumbers();
	res = nr[0] - nr[1];
	resultElem.innerHTML = res;
} // End sub

// Multiplicera talen
function mult() {
	var nr, res; // Array med input-värdena och variabel för resultat
	nr = getNumbers();
	res = nr[0] * nr[1];
	resultElem.innerHTML = res;
} // End mult

// Dividera talen
function div() {
	var nr, res; // Array med input-värdena och variabel för resultat
	nr = getNumbers();
	res = nr[0] / nr[1];
	resultElem.innerHTML = res;
} // End div