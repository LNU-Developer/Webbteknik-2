// JavaScript

// Globala variabler
var resultElem; // Referens till div-elementet för resultat

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	resultElem = document.getElementById("result");
	document.getElementById("redBtn").onclick = function() {selectColor("röd")};
	document.getElementById("greenBtn").onclick = function() {selectColor("grön")};
	document.getElementById("blueBtn").onclick = function() {selectColor("blå")};
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Vald färg
function selectColor(color) {
	resultElem.innerHTML = "Du valde " + color + " färg.";
} // End selectColor
