// JavaScript

// Globala variabler
var fruit1Elem, fruit2Elem; // Referenser till input-taggarna för frukt
var flower1Elem, flower2Elem; // Referenser till input-taggarna för blommor
var resultElem; // Referens till div-elementet för pris

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	fruit1Elem = document.getElementById("fruit1");
	fruit2Elem = document.getElementById("fruit2");
	flower1Elem = document.getElementById("flower1");
	flower2Elem = document.getElementById("flower2");
	resultElem = document.getElementById("result");
	document.getElementById("fruitBtn").onclick = priceForFruits;
	document.getElementById("flowerBtn").onclick = priceForFlowers;
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Beräkna momsen och skriv ut den
function calculateVAT(price,VATrate) {
	var VAT; // Moms på priset enligt medskickad momssats
	VAT = VATrate/100 * price;
	resultElem.innerHTML += "<p>Moms = " + VAT.toFixed(2) + "</p>";
} // End calculateVAT

// Beräkna pris för frukt
function priceForFruits() {
	var nr1, nr2; // Talen som avlsäses ur textfälten
	var sum; // Prissumman
	nr1 = Number(fruit1Elem.value);
	nr2 = Number(fruit2Elem.value);
	sum = nr1*3.5 + nr2*4.65;
	resultElem.innerHTML = "<p>Pris exkl. moms = " + sum.toFixed(2) + "</p>";
	calculateVAT(sum,12);
} // End priceForFruits

// Beräkna pris för frukt
function priceForFlowers() {
	var nr1, nr2; // Talen som avlsäses ur textfälten
	var sum; // Prissumman
	nr1 = Number(flower1Elem.value);
	nr2 = Number(flower2Elem.value);
	sum = nr1*18.7 + nr2*24.95;
	resultElem.innerHTML = "<p>Pris exkl. moms = " + sum.toFixed(2) + "</p>";
	tax = calculateVAT(sum,25);
} // End priceForFlowers
