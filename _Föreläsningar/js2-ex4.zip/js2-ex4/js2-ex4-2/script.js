// JavaScript

// Globala variabler
var input1Elem, input2Elem; // Referenser till input-taggarna
var resultElem; // Referens till div-elementet för resultat
var nr1, nr2; // Talen som avlsäses ur textfälten

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	input1Elem = document.getElementById("input1");
	input2Elem = document.getElementById("input2");
	resultElem = document.getElementById("result");
	document.getElementById("addBtn").onclick = add;
	document.getElementById("subBtn").onclick = sub;
	document.getElementById("multBtn").onclick = mult;
	document.getElementById("divBtn").onclick = div;
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Avläs textfälten
function getNumbers() {
	nr1 = Number(input1Elem.value);
	nr2 = Number(input2Elem.value);
} // End getNumbers

// Summera talen
function add() {
	var res; // Lokal variabel
	getNumbers();
	res = nr1 + nr2;
	resultElem.innerHTML = res;
} // End add

// Subtrahera talen
function sub() {
	var res; // Lokal variabel
	getNumbers();
	res = nr1 - nr2;
	resultElem.innerHTML = res;
} // End sub

// Multiplicera talen
function mult() {
	var res; // Lokal variabel
	getNumbers();
	res = nr1 * nr2;
	resultElem.innerHTML = res;
} // End mult

// Dividera talen
function div() {
	var res; // Lokal variabel
	getNumbers();
	res = nr1 / nr2;
	resultElem.innerHTML = res;
} // End div