// JavaScript

// Variabler med referenser till input-taggarna och div-elementet för resultat
var input1Elem, input2Elem, resultElem;

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	input1Elem = document.getElementById("input1");
	input2Elem = document.getElementById("input2");
	resultElem = document.getElementById("result");
	document.getElementById("addBtn").onclick = add;
	document.getElementById("subBtn").onclick = sub;
	document.getElementById("multBtn").onclick = mult;
	document.getElementById("divBtn").onclick = div;
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Summera talen
function add() {
	var nr1, nr2, res;
	nr1 = Number(input1Elem.value);
	nr2 = Number(input2Elem.value);
	res = nr1 + nr2;
	resultElem.innerHTML = res;
} // End add

// Subtrahera talen
function sub() {
	var nr1, nr2, res;
	nr1 = Number(input1Elem.value);
	nr2 = Number(input2Elem.value);
	res = nr1 - nr2;
	resultElem.innerHTML = res;
} // End sub

// Multiplicera talen
function mult() {
	var nr1, nr2, res;
	nr1 = Number(input1Elem.value);
	nr2 = Number(input2Elem.value);
	res = nr1 * nr2;
	resultElem.innerHTML = res;
} // End mult

// Dividera talen
function div() {
	var nr1, nr2, res;
	nr1 = Number(input1Elem.value);
	nr2 = Number(input2Elem.value);
	res = nr1 / nr2;
	resultElem.innerHTML = res;
} // End div