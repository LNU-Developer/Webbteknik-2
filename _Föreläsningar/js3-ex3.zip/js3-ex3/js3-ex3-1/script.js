// JavaScript

// Globala variabler
var input1Elem; // Referens till input-taggen för textfäkltet
var resultElem; // Referens till div-elementet för resultat
var flowers; // Array med blommor

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	input1Elem = document.getElementById("input1");
	resultElem = document.getElementById("result");
	document.getElementById("addBtn").onclick = addFlower;
	document.getElementById("writeBtn").onclick = writeFlowers;
	document.getElementById("roseBtn").onclick = changeRose;
	flowers = ["tulpan","maskros","vitsippa","blåsippa","prästkrage"];
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Skriv ut innehåll i arrayen
function writeFlowers() {
	flowers.sort();
	resultElem.innerHTML = "<p>Alla blommor: " + flowers.join(" - ") + "</p>";
	resultElem.innerHTML += "<p>Antal blommor: " + flowers.length + "</p>";
} // End writeFlowers

// Lägg till en ny blomma sist i arrayen
function addFlower() {
	var newFlower; // Namn på ny blomma som användaren skriver i textfältet
	newFlower = input1Elem.value;
	newFlower = newFlower.toLowerCase();
	if (flowers.indexOf(newFlower) > -1) {
		resultElem.innerHTML = "<p>Blomman finns redan i arrayen.</p>";
	}
	else {
		flowers.push(newFlower);
		resultElem.innerHTML = "<p>Ny blomma inlagd: " + flowers.join(", ") + "</p>";
	}
} // End addFlower

// Ändra innehåll. Om "maskros" finns i arrayen, byt till "ros".
function changeRose() {
	var i; // Index till element med "maskros", om det finns
	i = flowers.indexOf("maskros");
	if (i > -1) {
		flowers[i] = "ros";
		resultElem.innerHTML = "<p>Ny blomma inlagd: " + flowers.join(", ") + "</p>";
	}
	else {
		resultElem.innerHTML = "<p>Hittar ingen maskros.</p>";
	}
} // End changeRose