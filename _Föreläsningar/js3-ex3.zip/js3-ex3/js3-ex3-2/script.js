// JavaScript

// Globala variabler
var largePictElem;

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	largePictTag = document.getElementById("largePict");
	document.getElementById("pict1").onclick = function() {showLargePict(1)};
	document.getElementById("pict2").onclick = function() {showLargePict(2)};
	document.getElementById("pict3").onclick = function() {showLargePict(3)};
	document.getElementById("pict4").onclick = function() {showLargePict(4)};
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Visa stor bild för den bild som användaren klickat på
function showLargePict(pictNr) {
	var url; // URL för den bild man klickat på
	var urlArr; // Array med URL:ens delar mellan /
	url = document.getElementById("pict"+pictNr).src;
	urlArr = url.split("/");
	urlArr[urlArr.length-2] = "large";
	largePictTag.src = urlArr.join("/");
} // End showLargePict

/* --- Funktionen från js3-ex2-2 ---
function showLargePict(pictNr) {
	var url; // URL för den bild man klickat på
	var lastSlashPos; // Snedstrecket framför filnamnet
	var filename; // Filnamn för den bild man klickat på
	url = document.getElementById("pict"+pictNr).src;
	lastSlashPos = url.lastIndexOf("/");
	filename = url.substring(lastSlashPos+1);
	largePictTag.src = "pics/large/" + filename;
} // End showLargePict
*/
