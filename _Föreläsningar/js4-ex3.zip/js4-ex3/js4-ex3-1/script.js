// JavaScript Document

// Globala variabler
var msgElem;	// Referens till elementet för meddelanden

// Initiera globala variabler och koppla funktion till knapp
function init() {
	var i;			// Loopvariabel
	var boxes;		// Array med de inre boxarna
	var formElem;	// form-elementet
	var textFields;	// Array med textfälten
	
	boxes = document.getElementById("boxes").getElementsByTagName("div");
	for (i=0; i<boxes.length; i++) {
		addListener(boxes[i],"click",boxClick);
		addListener(boxes[i],"mouseover",boxOver);
		addListener(boxes[i],"mouseout",boxOut);
	}
	
	formElem = document.getElementById("testForm");
	textFields = formElem.getElementsByTagName("input");
	for (i=0; i<textFields.length-1; i++) {
		addListener(textFields[i],"blur",leaveField);
	}
	addListener(formElem,"submit",checkForm);
	
	msgElem = document.getElementById("message");
} // End init
addListener(window,"load",init);

// Klick på någon av de inre boxarna
function boxClick() {
	var symbols = ["&star;","&otimes;","&cupdot;","&plusb;","&bowtie;","&smashp;"]; // Symboler till boxen
	var oldSymb= this.innerHTML; // Gamla symbolen i boxen
	while (oldSymb == this.innerHTML) {
		this.innerHTML = symbols[Math.floor(symbols.length*Math.random())];
	}
	msgElem.innerHTML = "";
} // End boxClick

// Muspekaren är över en box
function boxOver() {
	msgElem.innerHTML = "Muspekaren är nu över boxen.";
} // End boxOver

// Muspekaren tas bort från boxen
function boxOut() {
	msgElem.innerHTML = "";
} // End boxOut

// Man lämnar ett textfält
function leaveField() {
	msgElem.innerHTML = "Du skrev: " + this.value;
} // End leaveField

// Kontrollera och skicka formuläret
function checkForm() {
	alert("Nu skickas formuläret");
} // End checkForm
