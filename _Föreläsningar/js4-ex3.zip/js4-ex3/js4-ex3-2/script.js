// JavaScript Document

// Globala variabler
var msgElem;	// Referens till elementet för meddelanden

// Initiera globala variabler och koppla funktion till knapp
function init() {
	addListener(document,"keyup",checkKey);
	//addListener(document,"keyup",checkKey);
	msgElem = document.getElementById("message");
} // End init
addListener(window,"load",init);

// Händelsehanterare för tangent
function checkKey() {
	msgElem.innerHTML += "Tangent ";
} // End checkKey