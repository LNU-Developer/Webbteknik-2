// JavaScript

// Variabler med referenser till input-taggarna och div-elementet för resultat
var input1Elem, resultElem;

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
// Här tas det fram referenser till textfälten för input och div-elementet för resultat
// Knappen för att köra programmet kopplas till funktionen testScript
function init() {
	input1Elem = document.getElementById("input1");
	resultElem = document.getElementById("result");
	document.getElementById("runBtn").onclick = testScript;
} // End init
window.onload = init; // Se till att init aktiveras då sidan är inladdad


/* ----- Testfunktionen ----- */

// Funktion med den kod som ska testas
function testScript() {
	// Deklaration av variabler
	var nr1, sum;

	nr1 = Number(input1Elem.value);
	
	resultElem.innerHTML = "";
	
	sum = 0;
	while (sum < 100) {
		sum = sum + nr1;
		resultElem.innerHTML += sum + ", ";
	}
	resultElem.innerHTML += "Slutsumman blev " + sum + "<br>";
	
} // End testScript
