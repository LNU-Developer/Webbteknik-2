// JavaScript

// Variabler med referenser till input-taggarna och div-elementet för resultat
var input1Elem, resultElem;

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
// Här tas det fram referenser till textfälten för input och div-elementet för resultat
// Knappen för att köra programmet kopplas till funktionen testScript
function init() {
	input1Elem = document.getElementById("input1");
	resultElem = document.getElementById("result");
	document.getElementById("runBtn").onclick = testScript;
} // End init
window.onload = init; // Se till att init aktiveras då sidan är inladdad


/* ----- Testfunktionen ----- */

// Funktion med den kod som ska testas
function testScript() {
	// Deklaration av variabler
	var i, nr1, sum;

	nr1 = Number(input1Elem.value);
	
	resultElem.innerHTML = "";
	
	for (i = 0; i < 10; i++) {
		resultElem.innerHTML += i + ", ";
	}
	
	resultElem.innerHTML += "<br>";
	
	for (i = 9; i >= 0; i--) {
		resultElem.innerHTML += i + ", ";
	}
	
	resultElem.innerHTML += "<br>";
	
	sum = 0;
	for (i = 0; i < 10; i++) {
		sum = sum + nr1;
		if (sum > 100) break;
		resultElem.innerHTML += sum + ", ";
	}
	resultElem.innerHTML += "Slutsumman blev " + sum;
	
} // End testScript
