// JavaScript

// Globala variabler
var input1Elem, input2Elem; // Referenser till input-taggarna för textfälten
var resultElem; // Referens till div-elementet för resultat
var allWords;  // Array med alla ord

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	input1Elem = document.getElementById("input1");
	input2Elem = document.getElementById("input2");
	resultElem = document.getElementById("result");
	document.getElementById("runBtn").onclick = createLoremIpsum;
	allWords = ["Lorem","ipsum","dolor","sit","amet,","consectetur","adipiscing","elit","Quisque","egestas,","ante","vel","accumsan","finibus","leo","orci","accumsan","elit,","sit","amet","vestibulum","orci","lectus","et","nunc","Nulla","facilisi","Aliquam","nec","dolor","turpis","Sed","ut","luctus","dui","ac","semper","ex","Donec","vitae","viverra","nulla.","Sed","scelerisque","volutpat","tincidunt","Suspendisse","venenatis","iaculis","pellentesque"];
} // End init
window.onload = init; // init aktiveras då sidan är inladdad


// Skapa slumpmässig Lorem ipsum-text
function createLoremIpsum() {
	var nrOfParagraphs, nrOfWords; // Värden fråntextfälten
	var generatedText; // Sträng med den genereradetexten
	var p, w; // Loopvariabler för stycken och ord
	var r; // Slumptal
	nrOfParagraphs = Number(input1Elem.value);
	nrOfWords = Number(input2Elem.value);
	generatedText = "";
	for (p = 0; p < nrOfParagraphs; p++) { // Loop för stycken
		generatedText += "<p>";
		for (w = 0; w < nrOfWords; w++) { // Loop för ord i styckena
			r = Math.floor(allWords.length * Math.random());
			generatedText += allWords[r] + " ";
		} // Inre for-loop
		generatedText += "</p>";
	} // Yttre for-loop
	resultElem.innerHTML = generatedText;
} // End createLoremIpsum
