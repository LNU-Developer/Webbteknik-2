// JavaScript

// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd
function init() {
	document.getElementById("dice1").onclick = function() {oneDice(1)};
	document.getElementById("dice2").onclick = function() {oneDice(2)};
	document.getElementById("dice3").onclick = function() {oneDice(3)};
	document.getElementById("allBtn").onclick = throwAllDice;
} // End init
window.onload = init; // init aktiveras då sidan är inladdad

// Generera ett slumptal mellan 1 och 6. Bestäm ny url utifrån talet och uppdatera bilden på tärningen.
function oneDice(imgNr) {
	var diceValue; // Tärningens värde (antal prickar)
	var newImgUrl; // URL för den nya bilden som ska läggas in i img-elementet
	diceValue = Math.floor(6*Math.random())+1;
	newImgUrl = "pics/" + diceValue + ".png";
	document.getElementById("dice"+imgNr).src = newImgUrl;
} // End oneDice

// Kasta alla tre tärningarna
function throwAllDice() {
	oneDice(1);
	oneDice(2);
	oneDice(3);
} // End throwAllDice