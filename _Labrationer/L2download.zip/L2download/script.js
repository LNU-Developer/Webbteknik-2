// JavaScript

// Globala variabler


// Funktion som körs då hela webbsidan är inladdad, dvs då all HTML-kod är utförd.
// Initiering av globala variabler samt koppling avfunktioner till knapparna.
function init() {
	
} // End init
window.onload = init; // Se till att init aktiveras då sidan är inladdad
